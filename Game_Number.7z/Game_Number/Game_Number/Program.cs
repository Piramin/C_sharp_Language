﻿using System;

namespace Game_Number
{
    class Program
    {
        static void Main(string[] args)
        {
            //Число вводимое игроком.
            int Player_Value;

            //Настройка количества игроков.
            int number_of_players;
            Console.Write("Введите количество игроков: ");
            number_of_players = Convert.ToInt32(Console.ReadLine());

            //Настройка онлайн режима игры.
            int Online_Game_Mode;
            Console.Write("Выберите режим игры:");
            Console.SetCursorPosition(21, 2);
            Console.WriteLine("1 - Однопользовательский");
            Console.SetCursorPosition(21, 3);
            Console.WriteLine("2 - Многопользовательский");
            Console.Write("Ваш режим игры: ");
            Online_Game_Mode = Convert.ToInt32(Console.ReadLine());

            //Выбор режима игры.
            int Game_Number_Min = 10, Game_Number_Max = 100;
            int Max_Step = Convert.ToInt32(Math.Pow(10, 4));
            int Game_Mod;
            Console.Write("Выберите модификацию игры:");
            Console.SetCursorPosition(21, 7);
            Console.WriteLine("1 - Стандартная игра.");
            Console.SetCursorPosition(21, 8);
            Console.WriteLine("2 - С ограничением количества шагов.");
            Console.SetCursorPosition(21, 9);
            Console.WriteLine("3 - Расширенное игровое число.");
            Console.Write("Ваш режим игры: ");
            Game_Mod = Convert.ToInt32(Console.ReadLine());

            switch (Game_Mod)
            {
                case 1:
                    break;
                case 2:
                    Console.Write("Введите максимальное количество шагов: ");
                    Max_Step = Convert.ToInt32(Console.ReadLine());
                    break;
                case 3:
                    Console.Write("Введите минимальное число: "); Game_Number_Min = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Введите максимальное число: "); Game_Number_Max = Convert.ToInt32(Console.ReadLine());
                    break;

            }

            //Задание числа
            Random random_value = new Random();
            int Game_Number = random_value.Next(Game_Number_Min, Game_Number_Max);

            //Выбор уровня сложности зависит от выбора режима игры. 
            //В многопользовательской игре это не имеет смысла.
            // Однопользовательский режим игры.
            if (Online_Game_Mode == 1)
            {
                //Выбор уровня сложности.
                int Game_Difficult;
                Console.WriteLine("Выберите уровень сложность игры:");
                Console.SetCursorPosition(32, 14);
                Console.WriteLine("1 - Легкий");
                Console.SetCursorPosition(32, 15);
                Console.WriteLine("2 - Средний");
                Console.SetCursorPosition(32, 16);
                Console.WriteLine("3 - Сложный");
                Console.Write("Ваш уровень сложности: ");
                Game_Difficult = Convert.ToInt32(Console.ReadLine());
                int Key = 0;

                //Имя игрока.
                string Player_Name;
                Console.Write("\nВведите имя игрока: ");
                Player_Name = Console.ReadLine();

                Console.WriteLine($"\nИгровое число: {Game_Number}");
                int step = 0;
                while (Game_Number > 0)
                {
                    Console.Write("\n");
                    if (step > Max_Step) { Console.WriteLine("Вы проиграли."); break; }
                    step++;
                    Console.WriteLine("Ход игрока " + Player_Name + $". Ход № {step}");
                    Console.WriteLine($"{new String('=', Console.WindowWidth)}");
                    Console.Write("Число игрока: ");
                    Player_Value = Convert.ToInt32(Console.ReadLine());
                    Game_Number -= Player_Value;

                    if (Game_Number == 0)
                    {
                        Console.WriteLine(Player_Name + " win!");
                        break;
                    }
                    else { Console.WriteLine($"Игровое число: {Game_Number}"); }

                    //Описание логики ИИ от уровня сложности.
                    for (int i = 1; i < number_of_players; i++)
                    {
                        if (step > Max_Step) { Console.WriteLine("Вы проиграли."); break; }
                        step++;
                        Console.WriteLine($"\nХод игрока Player{i}. Ход № {step}");
                        Console.WriteLine($"{new String('=', Console.WindowWidth)}");
                        switch (Game_Difficult)
                        {
                            case 1:
                                Player_Value = random_value.Next(0, 2);
                                Game_Number -= Player_Value;
                                break;
                            case 2:
                                if (Game_Number < 5) { Game_Number = 0; }
                                else
                                {
                                    Player_Value = random_value.Next(0, 5);
                                    Game_Number -= Player_Value;
                                }
                                break;
                            case 3:
                                if (Game_Number < 5) { Game_Number = 0; }
                                else
                                {
                                    for (int j = 2; j < 5; j++)
                                    {
                                        if ((Game_Number % j) == 0)
                                        {
                                            Player_Value = random_value.Next(0, j - 1);
                                            if (Player_Value == 0) { Player_Value = random_value.Next(0, 2); }
                                            Game_Number -= Player_Value;
                                            break;

                                        }
                                        else { Key++; }
                                    }
                                    if (Key == 3)
                                    {
                                        Player_Value = random_value.Next(0, 5);
                                        Game_Number -= Player_Value;
                                    }


                                }
                                break;
                        }
                        Console.WriteLine($"Число игрока Player{i}: {Player_Value}");
                        if (Game_Number == 0)
                        {
                            Console.WriteLine($"Player №{i}" + " win!");
                            break;
                        }
                        else
                        {
                            Console.WriteLine($"Игровое число: {Game_Number}");
                        }
                    }


                }
            }
            //Многопользовательский режим игры.
            else
            {
                //Ввод имен игроков.
                string[] Players_Names = new string[number_of_players];
                for (int j = 0; j < number_of_players; j++)
                {
                    Console.Write($"\nВведите имя {j + 1} игрока: ");
                    Players_Names[j] = Console.ReadLine();
                }
                //Многопользовательская игра.
                Console.WriteLine($"\nИгровое число: {Game_Number}");
                int step = 0;
                int i = 0;
                while (Game_Number > 0)
                {
                    Console.Write("\n");
                    if (step > Max_Step) { Console.WriteLine("Вы проиграли."); break; }
                    step++;
                    Console.WriteLine("Ход игрока " + Players_Names[i] + $". Ход № {step}");
                    Console.WriteLine($"{new String('=', Console.WindowWidth)}");
                    Console.Write("Число игрока: ");
                    Player_Value = Convert.ToInt32(Console.ReadLine());
                    Game_Number -= Player_Value;

                    if (Game_Number == 0)
                    {
                        Console.WriteLine(Players_Names[i] + " win!");
                        break;
                    }
                    else { Console.WriteLine($"Игровое число: {Game_Number}"); }

                    if ((++i) == number_of_players) { i = 0; }
                }

            }
        }
    }
}
